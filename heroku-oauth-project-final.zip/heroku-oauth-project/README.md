# Proyecto Node.js con Autenticación Completa y API Segura

Este proyecto es una aplicación Node.js/Express que integra autenticación de usuarios con múltiples estrategias (local, Google, Facebook), seguridad de API RESTful con JSON Web Tokens (JWT), gestión de bases de datos con MongoDB (local para desarrollo y Atlas para producción), envío de correos electrónicos (Ethereal para desarrollo y SendGrid para producción) y monitoreo con New Relic. Está configurado para ser desplegado en Heroku.

## Requisitos Previos

Antes de ejecutar o desplegar este proyecto, asegúrate de tener:

*   Node.js y npm instalados.
*   Una cuenta de Google Developer Console para obtener `GOOGLE_CLIENT_ID` y `GOOGLE_CLIENT_SECRET`.
*   Una cuenta de Facebook Developer para obtener `FACEBOOK_APP_ID` y `FACEBOOK_APP_SECRET`.
*   Una cuenta de MongoDB Atlas para obtener `MONGO_URI` de producción.
*   Una cuenta de SendGrid para obtener `SENDGRID_API_KEY` y configurar `SENDGRID_FROM_EMAIL`.
*   Una cuenta de New Relic para obtener `NEW_RELIC_LICENSE_KEY`.
*   Heroku CLI instalado y configurado.

## Configuración de Variables de Entorno

Crea un archivo `.env` en la raíz del proyecto con las siguientes variables:

```
NODE_ENV=development
PORT=3000

GOOGLE_CLIENT_ID=TU_GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET=TU_GOOGLE_CLIENT_SECRET

FACEBOOK_APP_ID=TU_FACEBOOK_APP_ID
FACEBOOK_APP_SECRET=TU_FACEBOOK_APP_SECRET

MONGO_URI=TU_MONGO_URI_ATLAS_PRODUCCION

SENDGRID_API_KEY=TU_SENDGRID_API_KEY
SENDGRID_FROM_EMAIL=tu_email_verificado@ejemplo.com

JWT_SECRET=TU_SECRETO_JWT_SEGURO

NEW_RELIC_LICENSE_KEY=TU_NEW_RELIC_LICENSE_KEY
NEW_RELIC_APP_NAME=Mi Proyecto Heroku
```

**Nota:** El archivo `.env` no debe ser subido a tu repositorio de Git por razones de seguridad.

## Instalación

1.  Clona el repositorio:
    ```bash
    git clone <URL_DE_TU_REPOSITORIO>
    cd heroku-oauth-project
    ```
2.  Instala las dependencias:
    ```bash
    npm install
    ```

## Ejecución Local

Para ejecutar la aplicación en tu entorno local (desarrollo):

```bash
npm start
```

O si prefieres usar `nodemon` para reinicios automáticos durante el desarrollo:

```bash
npm install -g nodemon
nodemon app.js
```

La aplicación estará disponible en `http://localhost:3000` (o el puerto que hayas configurado en `.env`).

## Despliegue en Heroku

1.  Asegúrate de tener un repositorio Git inicializado y el código commiteado.
2.  Crea una nueva aplicación en Heroku:
    ```bash
    heroku create tu-nombre-de-app
    ```
3.  Configura las variables de entorno en Heroku. Puedes hacerlo a través del dashboard de Heroku o usando el CLI:
    ```bash
    heroku config:set NODE_ENV=production
    heroku config:set GOOGLE_CLIENT_ID=TU_GOOGLE_CLIENT_ID
    heroku config:set GOOGLE_CLIENT_SECRET=TU_GOOGLE_CLIENT_SECRET
    heroku config:set FACEBOOK_APP_ID=TU_FACEBOOK_APP_ID
    heroku config:set FACEBOOK_APP_SECRET=TU_FACEBOOK_APP_SECRET
    heroku config:set MONGO_URI=TU_MONGO_URI_ATLAS_PRODUCCION
    heroku config:set SENDGRID_API_KEY=TU_SENDGRID_API_KEY
    heroku config:set SENDGRID_FROM_EMAIL=tu_email_verificado@ejemplo.com
    heroku config:set JWT_SECRET=TU_SECRETO_JWT_SEGURO
    heroku config:set NEW_RELIC_LICENSE_KEY=TU_NEW_RELIC_LICENSE_KEY
    heroku config:set NEW_RELIC_APP_NAME="Mi Proyecto Heroku"
    ```
    **Importante:** Asegúrate de que `MONGO_URI` apunte a tu base de datos de MongoDB Atlas para producción.

4.  Despliega el código a Heroku:
    ```bash
    git push heroku main
    ```

5.  Abre la aplicación en tu navegador:
    ```bash
    heroku open
    ```

## Verificación de Requisitos

Este proyecto cumple con los siguientes requisitos:

1.  **Atributos de Usuario:** El modelo `User.js` incluye `email`, `password` (hasheado), `passwordResetToken`, `passwordResetTokenExpires`, `isVerified`.
2.  **Modelo de Token:** El modelo `Token.js` tiene una referencia al usuario, el token y la fecha de creación/expiración.
3.  **Email ejecutado:** Se envían emails de bienvenida con verificación y de recuperación de contraseña (ver `config/mailer.js` y `routes/auth.js`).
4.  **Email de bienvenida con link de verificación:** Implementado en el registro de usuarios locales.
5.  **Vistas de login, recupero de password y demás:** `views/login.html`, `views/register.html`, `views/forgot-password.html`, `views/reset-password.html`, `views/profile.html`.
6.  **`serializeUser` y `deserializeUser`:** Implementados en `config/passport.js`.
7.  **Credenciales verdaderas e incorrectas:** Manejadas por la estrategia `passport-local` en `config/passport.js` y `routes/auth.js`.
8.  **Acceso denegado a URLs directas/redirigido al login:** Implementado con el middleware `ensureAuthenticated` en `routes/index.js`.
9.  **Autenticación con Postman y obtención de token:** Realiza un `POST` a `/auth/api/login` con `email` y `password`. Recibirás un JWT.
10. **Acceso a recursos con token válido/error sin autenticar:**
    *   Para acceder a `/api/bicicletas` (GET o POST), incluye el JWT en el header `Authorization: Bearer <tu_token_jwt>`.
    *   Sin el token, recibirás un error de autenticación.

## Estructura del Proyecto

```
heroku-oauth-project/
├── app.js
├── package.json
├── Procfile
├── README.md
├── .env (no se sube a git)
├── config/
│   ├── passport.js
│   └── mailer.js
├── models/
│   ├── User.js
│   ├── Token.js
│   └── Bicicleta.js
├── routes/
│   ├── auth.js
│   ├── index.js
│   └── bicicletas.js
├── views/
│   ├── index.html
│   ├── login.html
│   ├── register.html
│   ├── forgot-password.html
│   ├── reset-password.html
│   └── profile.html
└── public/
    └── (archivos estáticos, si los hubiera)
```

---

**Autor:** Manus AI
